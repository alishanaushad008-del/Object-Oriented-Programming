#ifndef FEEDENGINE_H
#define FEEDENGINE_H

#include <iostream>
#include <vector>
#include <fstream>

#include "User.h"
#include "Post.h"
#include "Functions.h"

using namespace std;

class FeedEngine {

private:

    static FeedEngine* instance;

    FeedEngine() {}

public:

    static FeedEngine* getInstance() {

        if (!instance)
            instance = new FeedEngine();

        return instance;
    }

    bool isInterest(User &user, Post &post) {

        for (string i : user.getInterests()) {

            string a = i;
            string b = post.getCategory();

            for (char &c : a)
                c = tolower(c);

            for (char &c : b)
                c = tolower(c);

            if (b.find(a) != string::npos ||
                a.find(b) != string::npos)

                return true;
        }

        return false;
    }

    void showAllPosts(
        User &user,
        vector<Post> &posts
    ) {

        printBox("ALL POSTS");

        cout << "ID\tTitle\t\tCategory\tLikes\n";

        cout << "----------------------------------------------\n";

        for (auto &p : posts) {

            p.display();

            if (isInterest(user, p))
                cout << YELLOW
                     << "   MATCHES YOUR INTEREST"
                     << RESET;

            cout << endl;
        }
    }

    void showFeed(
        vector<Post> &posts,
        string userName
    ) {

        printBox("YOUR FEED");

        cout << "Hello "
             << GREEN << userName
             << RESET << "!\n";

        bool found = false;

        for (auto &p : posts) {

            if (p.isRecentlyLiked()) {

                p.display();

                cout << YELLOW
                     << "  -> (RECENTLY LIKED!)"
                     << RESET << endl;

                found = true;
            }
        }

        if (!found)
            cout << "No recently liked posts.\n";
    }

    void showRecommendations(
        User &user,
        vector<Post> &posts
    ) {

        printBox("RECOMMENDED FOR YOU");

        bool found = false;

        for (auto &p : posts) {

            if (isInterest(user, p)) {

                p.display();

                cout << YELLOW
                     << "  -> (BASED ON YOUR INTEREST)"
                     << RESET << endl;

                found = true;
            }
        }

        if (!found)
            cout << "No recommendations available.\n";
    }

    void showTopPosts(
        vector<Post> &posts
    ) {

        printBox("TOP TRENDING POSTS");

        for (int i = 0; i < posts.size(); i++) {

            for (int j = i + 1;
                 j < posts.size();
                 j++) {

                if (posts[j].getLikes()
                    > posts[i].getLikes())

                    swap(posts[i], posts[j]);
            }
        }

        for (int i = 0;
             i < 5 && i < posts.size();
             i++) {

            posts[i].display();

            cout << endl;
        }
    }

    void saveToFile(
        vector<Post> &posts
    ) {

        ofstream file("posts.txt");

        for (auto &p : posts)
            file << p.getId()
                 << " "
                 << p.getLikes()
                 << endl;
    }
};

FeedEngine* FeedEngine::instance = nullptr;

#endif