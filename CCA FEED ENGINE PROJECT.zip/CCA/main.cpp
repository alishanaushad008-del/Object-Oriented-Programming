#include "FeedEngine.h"

int main() {

    User user;

    FeedEngine* engine =
        FeedEngine::getInstance();

    vector<Post> posts;

    // ===== ORIGINAL POSTS =====

    posts.push_back(
        Post(1,
        "Football Highlights",
        "Sports"));

    posts.push_back(
        Post(2,
        "AI Revolution",
        "Technology"));

    posts.push_back(
        Post(3,
        "Makeup Tutorial",
        "Makeup"));

    posts.push_back(
        Post(4,
        "Beauty Skincare Routine",
        "Beauty"));

    posts.push_back(
        Post(5,
        "Study Tips",
        "Education"));

    posts.push_back(
        Post(6,
        "Healthy Diet",
        "Health"));

    posts.push_back(
        Post(7,
        "Gym Workout",
        "Fitness"));

    posts.push_back(
        Post(8,
        "Travel Vlog",
        "Travel"));

    posts.push_back(
        Post(9,
        "Coding Basics",
        "Technology"));

    posts.push_back(
        Post(10,
        "Fashion Trends",
        "Fashion"));

    posts.push_back(
        Post(11,
        "Gaming Review",
        "Gaming"));

    posts.push_back(
        Post(12,
        "Science Facts",
        "Education"));

    posts.push_back(
        Post(13,
        "News Update",
        "News"));

    user.createProfile();

    user.addInterests();

    int choice;

    while (true) {

        printBox("MAIN MENU");

        cout << "1. View Profile\n";
        cout << "2. View All Posts\n";
        cout << "3. Like a Post\n";
        cout << "4. Show My Feed\n";
        cout << "5. Recommended Posts\n";
        cout << "6. Top Trending Posts\n";
        cout << "7. Exit\n";

        cout << "Enter choice: ";

        if (!(cin >> choice)) {

            printError(
                "INVALID INPUT! ENTER NUMBER 1-7"
            );

            cin.clear();

            cin.ignore(
                numeric_limits<streamsize>::max(),
                '\n'
            );

            continue;
        }

        if (choice == 1)
            user.showProfile();

        else if (choice == 2)
            engine->showAllPosts(user, posts);

        else if (choice == 3) {

            int id;

            cout << "Enter Post ID: ";

            if (!(cin >> id)) {

                printError("INVALID INPUT!");

                cin.clear();

                cin.ignore(
                    numeric_limits<streamsize>::max(),
                    '\n'
                );

                continue;
            }

            bool found = false;

            for (auto &p : posts) {

                if (p.getId() == id) {

                    p.likePost();

                    printSuccess(
                        "Post Liked!"
                    );

                    found = true;
                }

                else {
                    p.resetRecent();
                }
            }

            if (!found)
                printError(
                    "Invalid Post ID!"
                );
        }

        else if (choice == 4)
            engine->showFeed(
                posts,
                user.getName()
            );

        else if (choice == 5)
            engine->showRecommendations(
                user,
                posts
            );

        else if (choice == 6)
            engine->showTopPosts(
                posts
            );

        else if (choice == 7) {

            engine->saveToFile(
                posts
            );

            cout << GREEN
                 << "Exiting Program...\n"
                 << RESET;

            break;
        }

        else
            printError(
                "INVALID CHOICE!"
            );
    }

    return 0;
}