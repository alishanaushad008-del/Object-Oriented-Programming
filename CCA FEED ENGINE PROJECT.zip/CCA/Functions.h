#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <iostream>
using namespace std;

#define RED "\033[31m"
#define GREEN "\033[32m"
#define YELLOW "\033[33m"
#define BLUE "\033[34m"
#define CYAN "\033[36m"
#define RESET "\033[0m"

inline void printBox(string title) {

    cout << CYAN
         << "\n====================================\n";

    cout << "   " << title << endl;

    cout << "====================================\n"
         << RESET;
}

inline void printError(string msg) {
    cout << RED << msg << RESET << endl;
}

inline void printSuccess(string msg) {
    cout << GREEN << msg << RESET << endl;
}

#endif