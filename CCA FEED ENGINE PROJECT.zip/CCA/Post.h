#ifndef POST_H
#define POST_H

#include <iostream>
#include <string>

#include "Content.h"
#include "Functions.h"

using namespace std;

class Post : public Content {

private:
    int id;
    string title;
    string category;
    int likes;
    bool recentlyLiked;

public:

    static int totalPosts;

    Post(int i, string t, string c)
        : id(i),
          title(t),
          category(c),
          likes(0),
          recentlyLiked(false) {

        totalPosts++;
    }

    int getId() const {
        return id;
    }

    string getTitle() const {
        return title;
    }

    string getCategory() const {
        return category;
    }

    int getLikes() const {
        return likes;
    }

    bool isRecentlyLiked() const {
        return recentlyLiked;
    }

    void likePost() {
        likes++;
        recentlyLiked = true;
    }

    void resetRecent() {
        recentlyLiked = false;
    }

    void display() const override {

        cout << CYAN << id << RESET << "\t"
             << title << "\t\t"
             << category << "\t\t"
             << GREEN << likes << RESET;
    }

    friend void debugPost(Post p);
};

int Post::totalPosts = 0;

inline void debugPost(Post p) {}

#endif