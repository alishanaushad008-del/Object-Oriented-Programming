#ifndef USER_H
#define USER_H

#include <iostream>
#include <vector>
#include <string>
#include <limits>

#include "Functions.h"

using namespace std;

class User {

private:
    string name;
    int age;
    vector<string> interests;

public:

    void createProfile() {

        printBox("CREATE PROFILE");

        // ===== NAME =====
        while (true) {

            cout << "Enter Name: ";

            getline(cin >> ws, name);

            bool valid = true;

            if (name.empty())
                valid = false;

            for (char c : name) {
                if (isdigit(c)) {
                    valid = false;
                    break;
                }
            }

            if (valid)
                break;

            printError(
                "INVALID INPUT! ENTER NAME ONLY"
            );
        }

        // ===== AGE =====
        while (true) {

            cout << "Enter Age: ";

            if (cin >> age && age > 0)
                break;

            printError(
                "INVALID INPUT! ENTER NUMBER ONLY"
            );

            cin.clear();

            cin.ignore(
                numeric_limits<streamsize>::max(),
                '\n'
            );
        }
    }

    void addInterests() {

        int n;

        while (true) {

            cout << "How many interests? ";

            if (cin >> n && n > 0)
                break;

            printError(
                "INVALID INPUT! ENTER NUMBER ONLY"
            );

            cin.clear();

            cin.ignore(
                numeric_limits<streamsize>::max(),
                '\n'
            );
        }

        cin.ignore();

        for (int i = 0; i < n; i++) {

            string interest;

            while (true) {

                cout << "Enter interest "
                     << i + 1 << ": ";

                getline(cin, interest);

                bool valid = true;

                if (interest.empty())
                    valid = false;

                for (char c : interest) {
                    if (isdigit(c)) {
                        valid = false;
                        break;
                    }
                }

                if (valid)
                    break;

                printError(
                    "INVALID INPUT!"
                );
            }

            interests.push_back(interest);
        }
    }

    string getName() {
        return name;
    }

    vector<string> getInterests() {
        return interests;
    }

    void showProfile() {

        printBox("USER PROFILE");

        cout << "Name: "
             << GREEN << name
             << RESET << endl;

        cout << "Age: "
             << age << endl;

        cout << "Interests: ";

        for (auto &i : interests)
            cout << YELLOW
                 << i << " "
                 << RESET;

        cout << endl;
    }
};

#endif